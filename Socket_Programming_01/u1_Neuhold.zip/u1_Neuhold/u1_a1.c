#include <stdio.h>
#include <stdlib.h>

void server_process (int fd);

int main() {
  server_process(0);
  return 0;
}
